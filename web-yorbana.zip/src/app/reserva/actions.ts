"use server";

import { addMinutes } from "date-fns";
import { createServiceSupabaseClient } from "@/lib/supabase/admin";

const SERVICES = "bookido_services";
const BOOKINGS = "bookido_bookings";

export async function getBusyIntervalsAction(
  tenantSlug: string,
  rangeStartISO: string,
  rangeEndISO: string,
): Promise<
  { ok: true; intervals: { starts_at: string; ends_at: string }[] } | { ok: false; error: string }
> {
  const admin = createServiceSupabaseClient();
  if (!admin) {
    return { ok: false, error: "Supabase no está configurado en el servidor." };
  }

  const { data, error } = await admin
    .from(BOOKINGS)
    .select("starts_at, ends_at")
    .eq("tenant_slug", tenantSlug)
    .neq("status", "cancelled")
    .lt("starts_at", rangeEndISO)
    .gt("ends_at", rangeStartISO);

  if (error) {
    return { ok: false, error: error.message };
  }

  return { ok: true, intervals: data ?? [] };
}

export async function createBookingAction(input: {
  tenantSlug: string;
  serviceId: string;
  startsAtISO: string;
  customerName: string;
  customerEmail: string;
  customerPhone?: string;
  notes?: string;
}): Promise<{ ok: true } | { ok: false; error: string }> {
  const admin = createServiceSupabaseClient();
  if (!admin) {
    return { ok: false, error: "Supabase no está configurado en el servidor." };
  }

  const name = input.customerName.trim();
  const email = input.customerEmail.trim();
  if (name.length < 2 || name.length > 120) {
    return { ok: false, error: "Indica un nombre válido." };
  }
  if (email.length < 5 || email.length > 254 || !email.includes("@")) {
    return { ok: false, error: "Indica un correo válido." };
  }

  const { data: svc, error: svcErr } = await admin
    .from(SERVICES)
    .select("id, duration_minutes, active, tenant_slug")
    .eq("id", input.serviceId)
    .eq("tenant_slug", input.tenantSlug)
    .single();

  if (svcErr || !svc || !svc.active) {
    return { ok: false, error: "Servicio no disponible." };
  }

  const startsAt = new Date(input.startsAtISO);
  if (Number.isNaN(startsAt.getTime())) {
    return { ok: false, error: "Fecha u hora no válida." };
  }

  const endsAt = addMinutes(startsAt, svc.duration_minutes);

  const { data: conflicts, error: conflictErr } = await admin
    .from(BOOKINGS)
    .select("id")
    .eq("tenant_slug", input.tenantSlug)
    .neq("status", "cancelled")
    .lt("starts_at", endsAt.toISOString())
    .gt("ends_at", startsAt.toISOString());

  if (conflictErr) {
    return { ok: false, error: conflictErr.message };
  }
  if (conflicts?.length) {
    return {
      ok: false,
      error: "Ese horario acaba de ocuparse. Elige otra franja.",
    };
  }

  const { error: insertErr } = await admin.from(BOOKINGS).insert({
    tenant_slug: input.tenantSlug,
    service_id: input.serviceId,
    starts_at: startsAt.toISOString(),
    ends_at: endsAt.toISOString(),
    customer_name: name,
    customer_email: email,
    customer_phone: input.customerPhone?.trim() || null,
    notes: input.notes?.trim() || null,
    status: "confirmed",
  });

  if (insertErr) {
    return { ok: false, error: insertErr.message };
  }

  return { ok: true };
}
