import Link from "next/link";
import { BookingReservaClient } from "@/components/booking/BookingReservaClient";
import { getScheduleConfig, getTenantSlug } from "@/lib/booking/config";
import { createServiceSupabaseClient } from "@/lib/supabase/admin";
import type { ServiceRow } from "@/lib/booking/types";

export const dynamic = "force-dynamic";

export default async function ReservaPage() {
  const admin = createServiceSupabaseClient();
  const configured = admin !== null;
  const tenantSlug = getTenantSlug();
  const schedule = getScheduleConfig();

  let services: ServiceRow[] = [];
  if (admin) {
    const { data } = await admin
      .from("bookido_services")
      .select("id, name, duration_minutes")
      .eq("tenant_slug", tenantSlug)
      .eq("active", true)
      .order("sort_order", { ascending: true });
    services = (data as ServiceRow[] | null) ?? [];
  }

  return (
    <div className="min-h-screen bg-ink-950 bg-grid-fade">
      <div
        className="pointer-events-none fixed inset-x-0 top-0 z-50 h-px bg-gradient-to-r from-transparent via-rose-glow/40 to-transparent"
        aria-hidden
      />

      <header className="relative z-40 border-b border-white/[0.06] bg-ink-950/80 backdrop-blur-md">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-5 lg:px-8">
          <Link href="/" className="flex flex-col transition hover:opacity-90">
            <span className="font-display text-xl font-semibold tracking-wide text-white md:text-2xl">
              Yorbana
            </span>
            <span className="text-[11px] font-medium uppercase tracking-[0.35em] text-zinc-500">
              Nail Estudio
            </span>
          </Link>
          <Link
            href="/"
            className="text-sm text-zinc-400 transition hover:text-white"
          >
            ← Inicio
          </Link>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-6 py-14 lg:px-8 lg:py-20">
        <BookingReservaClient
          services={services}
          configured={configured}
          tenantSlug={tenantSlug}
          schedule={schedule}
        />
      </main>

      <footer className="border-t border-white/[0.06] px-6 py-8 lg:px-8">
        <p className="mx-auto max-w-6xl text-center text-xs text-zinc-600">
          Reservas con <span className="text-zinc-500">BookiDo</span>
        </p>
      </footer>
    </div>
  );
}
