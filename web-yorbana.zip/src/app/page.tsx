import Link from "next/link";
import { getLandingServices } from "@/lib/supabase";

export const revalidate = 60;

const OWNER = "Giolbana Calderón";
const LOCATION_LINE = "Gustavo Mejía Ricart, Santo Domingo, RD";
const SCHEDULE =
  "Martes a sábado: 9am – 7pm · Domingos: 8am – 3pm";
const EMAIL = "calderonmedinagiolbana@gmail.com";
const BRAND = "Yorbana Nail Estudio";

const highlights = [
  { label: "Ubicación", value: LOCATION_LINE },
  { label: "Horario", value: SCHEDULE },
  { label: "Dueña", value: OWNER },
];

const FALLBACK_SERVICES = [
  {
    id: "fallback-1",
    name: "Manicura",
    duration_minutes: 45,
    blurb:
      "Cuidado de uñas, cutículas y acabado impecable con esmaltes de calidad.",
  },
  {
    id: "fallback-2",
    name: "Pedicura",
    duration_minutes: 60,
    blurb:
      "Relajación y estética para pies, con higiene y mimo en cada paso.",
  },
  {
    id: "fallback-3",
    name: "Nail art",
    duration_minutes: 75,
    blurb:
      "Diseños a medida: minimal, french moderno o detalles que marcan diferencia.",
  },
];

function buildWhatsappReservaHref(): string {
  const raw = process.env.NEXT_PUBLIC_WHATSAPP_E164;
  const text = encodeURIComponent(
    `Hola, soy cliente interesado/a en ${BRAND}. Me gustaría reservar (${LOCATION_LINE}).`,
  );
  if (raw) {
    const digits = raw.replace(/\D/g, "");
    if (digits) return `https://wa.me/${digits}?text=${text}`;
  }
  return `https://wa.me/?text=${text}`;
}

export default async function Home() {
  const dbServices = await getLandingServices();
  const services =
    dbServices.length > 0
      ? dbServices.map((s) => ({
          id: s.id,
          name: s.name,
          duration_minutes: s.duration_minutes,
          blurb: `Sesión de aproximadamente ${s.duration_minutes} minutos. ${BRAND} en Santo Domingo.`,
        }))
      : FALLBACK_SERVICES;

  const whatsappHref = buildWhatsappReservaHref();

  return (
    <div className="min-h-screen bg-ink-950 bg-grid-fade">
      <div
        className="pointer-events-none fixed inset-x-0 top-0 z-50 h-px bg-gradient-to-r from-transparent via-rose-400/55 to-transparent"
        aria-hidden
      />

      <header className="header-yorbana-glass relative z-40">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-5 lg:px-8">
          <div className="flex flex-col">
            <span className="font-future text-xl font-semibold tracking-tight text-white md:text-2xl">
              Yorbana
            </span>
            <span className="text-[10px] font-medium uppercase tracking-future text-rose-200/55 md:text-[11px]">
              Nail Estudio
            </span>
          </div>
          <nav className="hidden items-center gap-10 text-sm text-zinc-400 md:flex">
            <a href="#servicios" className="transition hover:text-rose-200">
              Servicios
            </a>
            <a href="#experiencia" className="transition hover:text-rose-200">
              El estudio
            </a>
            <Link href="/reserva" className="transition hover:text-rose-200">
              Calendario
            </Link>
            <a href="#contacto" className="transition hover:text-rose-200">
              Contacto
            </a>
          </nav>
          <a
            href={whatsappHref}
            target="_blank"
            rel="noopener noreferrer"
            className="btn-whatsapp-neon-sm hidden sm:inline-flex"
          >
            WhatsApp
          </a>
        </div>
      </header>

      <main>
        <section className="relative overflow-hidden px-6 pb-28 pt-16 md:pb-36 md:pt-24 lg:px-8">
          <div className="pointer-events-none absolute -left-32 top-20 h-[28rem] w-[28rem] rounded-full bg-gradient-to-br from-rose-500/28 to-red-600/12 blur-[120px]" />
          <div className="pointer-events-none absolute -right-24 bottom-0 h-80 w-80 rounded-full bg-gradient-to-tl from-red-600/22 to-rose-400/12 blur-[100px]" />
          <div className="pointer-events-none absolute left-1/2 top-1/2 h-[520px] w-[520px] -translate-x-1/2 -translate-y-1/2 rounded-full border border-rose-400/[0.09] bg-[radial-gradient(circle_at_center,rgba(251,113,133,0.1),transparent_62%)] shadow-[0_0_80px_-20px_rgba(225,29,72,0.2)]" />

          <div className="relative mx-auto max-w-6xl">
            <p className="mb-4 inline-flex items-center gap-2 rounded-full border border-rose-300/25 bg-gradient-to-r from-rose-500/[0.1] to-red-600/[0.08] px-4 py-1.5 text-xs font-medium uppercase tracking-widest text-rose-100/85 shadow-neon-rose">
              <span className="h-1.5 w-1.5 rounded-full bg-gradient-to-br from-rose-300 to-red-500 shadow-[0_0_16px_rgba(251,113,133,0.95)]" />
              {BRAND} · {LOCATION_LINE}
            </p>
            <p className="mb-2 font-display text-sm italic tracking-elegant text-rose-200/55">
              Dirección creativa · {OWNER}
            </p>
            <h1 className="max-w-4xl font-display text-4xl font-semibold leading-[1.08] tracking-tight text-white sm:text-5xl md:text-6xl lg:text-[4rem] lg:leading-[1.05]">
              Belleza que se siente
              <br />
              <span className="bg-gradient-to-r from-rose-200 via-rose-400 to-red-500 bg-clip-text text-transparent drop-shadow-[0_0_48px_rgba(251,113,133,0.4)]">
                antes de verse
              </span>
            </h1>
            <p className="mt-6 max-w-xl text-lg leading-relaxed text-zinc-400 md:text-xl">
              Nail estudio con estética elegante y futurista: manicura, pedicura
              y nail art en un espacio femenino — la visión de{" "}
              <span className="text-rose-200/75">{OWNER}</span>.
            </p>
            <p className="mt-3 max-w-xl font-mono text-xs text-rose-200/50 md:text-sm">
              {SCHEDULE}
            </p>

            <div className="mt-12 flex max-w-2xl flex-col gap-4 sm:flex-row sm:flex-wrap sm:items-center">
              <a
                href={whatsappHref}
                target="_blank"
                rel="noopener noreferrer"
                className="btn-whatsapp-neon inline-flex w-full min-w-[280px] items-center justify-center sm:w-auto"
              >
                Reservar por WhatsApp
              </a>
              <Link
                href="/reserva"
                className="neon-border-soft inline-flex w-full items-center justify-center rounded-2xl px-8 py-4 text-base font-medium text-rose-50/95 transition hover:border-rose-300/50 hover:bg-rose-500/[0.08] sm:w-auto"
              >
                Ver calendario de reservas
              </Link>
            </div>
            <p className="mt-4 text-sm text-zinc-600">
              Respuesta en horario de apertura · También en{" "}
              <a
                href="#servicios"
                className="text-rose-300/65 underline decoration-rose-500/30 underline-offset-4 hover:text-rose-200/85"
              >
                carta de servicios
              </a>
            </p>

            <dl className="mt-20 grid gap-8 border-t border-rose-500/[0.15] pt-12 sm:grid-cols-3">
              {highlights.map((h) => (
                <div key={h.label}>
                  <dt className="text-xs uppercase tracking-wider text-rose-300/50">
                    {h.label}
                  </dt>
                  <dd className="mt-2 font-display text-base leading-snug text-white md:text-lg">
                    {h.value}
                  </dd>
                </div>
              ))}
            </dl>
          </div>
        </section>

        <section
          id="servicios"
          className="border-t border-rose-500/[0.1] bg-ink-900/35 px-6 py-24 lg:px-8"
        >
          <div className="mx-auto max-w-6xl">
            <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
              <div className="max-w-2xl">
                <p className="text-xs font-medium uppercase tracking-[0.28em] text-rose-300/85">
                  Carta · {BRAND}
                </p>
                <h2 className="mt-2 font-display text-3xl font-semibold tracking-tight text-white md:text-4xl lg:text-5xl">
                  Servicios
                </h2>
                <p className="mt-4 text-zinc-400">
                  Tratamientos que se sincronizan con nuestra base de datos;
                  siempre verás la carta actualizada.
                </p>
              </div>
              <a
                href={whatsappHref}
                target="_blank"
                rel="noopener noreferrer"
                className="btn-whatsapp-neon-sm inline-flex shrink-0"
              >
                Reservar por WhatsApp
              </a>
            </div>

            <ul className="mt-16 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {services.map((s, i) => (
                <li key={s.id} className="card-service-glass group">
                  <span className="absolute right-6 top-6 z-10 bg-gradient-to-br from-rose-200/35 to-red-500/25 bg-clip-text font-mono text-xs text-transparent">
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  <div className="relative z-10">
                    <div className="mb-4 h-px w-14 bg-gradient-to-r from-rose-300 via-rose-500 to-red-600 shadow-[0_0_12px_rgba(251,113,133,0.45)]" />
                    <h3 className="font-display text-2xl font-medium text-white">
                      {s.name}
                    </h3>
                    <p className="mt-2 text-xs uppercase tracking-wider text-rose-200/45">
                      {s.duration_minutes} minutos
                    </p>
                    <p className="mt-4 text-sm leading-relaxed text-zinc-400">
                      {s.blurb}
                    </p>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </section>

        <section id="experiencia" className="px-6 py-24 lg:px-8">
          <div className="mx-auto grid max-w-6xl gap-16 lg:grid-cols-2 lg:items-center">
            <div>
              <h2 className="font-display text-3xl font-semibold tracking-tight text-white md:text-4xl lg:text-5xl">
                Futuro suave,
                <span className="block bg-gradient-to-r from-rose-200 to-red-400 bg-clip-text text-transparent">
                  presente íntimo
                </span>
              </h2>
              <p className="mt-6 text-zinc-400 leading-relaxed">
                Líneas limpias, brillo contenido y un ambiente pensado para ti.
                En {BRAND} unimos técnica y sensibilidad para que cada detalle —
                forma, color, textura — dialogue con tu estilo.
              </p>
              <ul className="mt-10 space-y-5 text-sm text-zinc-300">
                <li className="flex gap-4">
                  <span className="mt-2 h-1 w-8 shrink-0 rounded-full bg-gradient-to-r from-rose-300 to-red-500 shadow-[0_0_14px_rgba(251,113,133,0.55)]" />
                  Higiene rigurosa y materiales acordes a un nail estudio premium.
                </li>
                <li className="flex gap-4">
                  <span className="mt-2 h-1 w-8 shrink-0 rounded-full bg-gradient-to-r from-rose-300 to-red-500 shadow-[0_0_14px_rgba(251,113,133,0.55)]" />
                  Paletas y siluetas que favorecen tu tono y tu rutina.
                </li>
                <li className="flex gap-4">
                  <span className="mt-2 h-1 w-8 shrink-0 rounded-full bg-gradient-to-r from-rose-300 to-red-500 shadow-[0_0_14px_rgba(251,113,133,0.55)]" />
                  Reservas BookiDo: WhatsApp o calendario web.
                </li>
              </ul>
            </div>
            <div className="relative aspect-[4/5] max-h-[440px] overflow-hidden rounded-3xl border border-rose-400/20 bg-ink-800/80 shadow-[0_0_64px_-10px_rgba(225,29,72,0.45)] backdrop-blur-sm">
              <div className="absolute inset-0 bg-gradient-to-br from-rose-600/28 via-transparent to-red-950/85" />
              <div className="absolute inset-0 flex flex-col items-center justify-center p-10 text-center">
                <span className="bg-gradient-to-br from-rose-100 to-red-400 bg-clip-text font-display text-6xl font-semibold text-transparent drop-shadow-[0_0_30px_rgba(251,113,133,0.35)] md:text-7xl">
                  Y
                </span>
                <p className="mt-6 font-future text-xs uppercase tracking-future text-rose-200/50">
                  {BRAND}
                </p>
                <p className="mt-3 max-w-xs text-xs leading-relaxed text-zinc-600">
                  Espacio reservado para tu foto del salón o vitrina cuando la
                  tengas.
                </p>
              </div>
            </div>
          </div>
        </section>

        <section
          id="contacto"
          className="border-t border-rose-500/[0.1] bg-ink-900/30 px-6 py-24 lg:px-8"
        >
          <div className="mx-auto max-w-6xl">
            <div className="panel-contact-glass">
              <div className="mx-auto max-w-2xl text-center">
                <h2 className="font-display text-3xl font-semibold tracking-tight text-white md:text-4xl">
                  ¿Hablamos por WhatsApp?
                </h2>
                <p className="mt-5 text-zinc-400">
                  Cuéntanos qué buscas y coordinamos tu visita en{" "}
                  <span className="text-rose-200/70">{LOCATION_LINE}</span>.
                  También puedes elegir día y hora en el calendario.
                </p>
                <a
                  href={whatsappHref}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-whatsapp-neon mt-10 inline-flex w-full min-w-[280px] items-center justify-center sm:w-auto"
                >
                  Reservar por WhatsApp
                </a>
                <div className="mt-8 flex flex-wrap items-center justify-center gap-4">
                  <Link
                    href="/reserva"
                    className="text-sm font-medium text-rose-300/95 hover:text-rose-200 hover:underline"
                  >
                    Abrir calendario de reservas
                  </Link>
                  <span className="text-rose-900/70">·</span>
                  <a
                    href={`mailto:${EMAIL}`}
                    className="text-sm text-zinc-500 transition hover:text-rose-200/85"
                  >
                    {EMAIL}
                  </a>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t border-rose-500/[0.12] px-6 py-12 lg:px-8">
        <div className="mx-auto grid max-w-6xl gap-8 text-sm text-zinc-500 md:grid-cols-[1fr_auto] md:items-end">
          <div>
            <p className="font-future text-lg font-semibold tracking-tight text-zinc-100 md:text-xl">
              {BRAND}
            </p>
            <p className="mt-2 max-w-md text-zinc-500">{LOCATION_LINE}</p>
            <p className="mt-1 font-mono text-xs text-zinc-600">{SCHEDULE}</p>
            <a
              href={`mailto:${EMAIL}`}
              className="mt-3 inline-block text-rose-300/75 transition hover:text-rose-200"
            >
              {EMAIL}
            </a>
          </div>
          <p className="text-right md:max-w-xs">
            Reservas con{" "}
            <span className="font-medium text-rose-200/65">BookiDo</span>
            <br />
            <span className="text-xs text-zinc-600">{OWNER}</span>
          </p>
        </div>
      </footer>
    </div>
  );
}
